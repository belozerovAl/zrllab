#ifndef bin_h
#define bin_h
#include <stdio.h>
void binory(char* line1, char* line2, char sim);
void binory_1(char* line1);
#endif

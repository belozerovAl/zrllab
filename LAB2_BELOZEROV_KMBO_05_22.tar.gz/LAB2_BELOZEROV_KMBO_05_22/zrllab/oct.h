#ifndef oct_h
#define oct_h
#include <stdio.h>
void oct(char* line1, char* line2, char sim);
void oct_1(char* line);
#endif
